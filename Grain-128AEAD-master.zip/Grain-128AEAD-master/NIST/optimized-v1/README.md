# LEGACY

This version is the optimized implementation of the original Grain-128AEAD version. This is only kept for reference and shall *not* be used for anything else than educational purposes.
