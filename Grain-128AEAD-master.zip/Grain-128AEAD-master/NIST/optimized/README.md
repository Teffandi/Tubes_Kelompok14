# Optimized versions

There are 4 versions of the opmized implementation that can be selected by changing the defines in the header:
- x64		(0, 0, 0)
- SSE3		(1, 0, 0)
- AVX512	(1, 1, 0)
- GF2		(1, 1, 1)


